# What is left

Status: 20 November 2026. All three deliverables are now prepared. See [what we have done](WHAT_WE_HAVE_DONE.md).

## Before you submit

- [ ] **Fill in your name, student number and email** in `report/report.tex` (title block and `\pdfinfo`), then rebuild the PDF:
  `cd report && pdflatex report.tex && pdflatex report.tex`, then copy `report/report.pdf` to `output/pdf/Small_Weather_Report.pdf` and run `python3 scripts/package.py`.
- [ ] **Template check.** The official ICCC author kit could not be downloaded in the build environment, so `report/iccc.sty` is a faithful reconstruction of the ICCC/AAAI layout (US letter, two columns, Times 10pt, centred headings, author-year citations). If your course supplies `iccc.sty`, copy it over `report/iccc.sty` and recompile; `report.tex` uses only standard macros. Alternatively paste the text into the Word template or the ICCC Overleaf template.
- [ ] Read the report and adjust the **Use of Generative AI** paragraph and any first-person statements so they describe your own contribution accurately.
- [ ] Confirm the submission destination and deadline in the course materials.

## Submit

| Deliverable | File |
| --- | --- |
| Report (4 pages, references included) | `output/pdf/Small_Weather_Report.pdf` |
| Source code + data + README | `output/zips/Small_Weather_Source.zip` |
| Presentation of three poems + full texts | `output/zips/Small_Weather_Presentation.zip` |

## Optional extensions (not required)

- Blind reader study (1 vs 48 candidates; plain vs illustrated), as designed in the report.
- Penalise phrase reuse across a collection to counter the diversity loss measured in `evaluation/selection_bias.json`.
